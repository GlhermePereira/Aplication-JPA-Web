package br.edu.fatecpg.Aplicacao.Jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacaoJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicacaoJpaApplication.class, args);
	}

}
