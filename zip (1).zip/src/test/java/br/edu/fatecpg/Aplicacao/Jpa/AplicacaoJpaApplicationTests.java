package br.edu.fatecpg.Aplicacao.Jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacaoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
